﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2728
{
    class Program
    {
        // Структура для хранения данных о студенте
        struct Student
        {
            public string FullName;
            public string City;
            public string Street;
            public string HouseApartment;
            public int DistanceToKrasnodar;

            public override string ToString()
            {
                return $"{FullName}, {City}, {Street}, {HouseApartment}, Расстояние до Краснадара: {DistanceToKrasnodar} км";
            }
        }

        static List<Student> students = new List<Student>();

        static void Main()
        {
            bool repeat = true;

            do
            {
                Console.Clear();
                Console.WriteLine("Управление списком студентов для общежития в Краснодаре");
                Console.WriteLine("1. Добавить нового студента");
                Console.WriteLine("2. Редактировать данные студента");
                Console.WriteLine("3. Вывести список студентов для общежития");
                Console.WriteLine("4. Сохранить данные в файл");
                Console.WriteLine("5. Выход");

                char choice = Console.ReadKey(true).KeyChar;
                Console.WriteLine();

                switch (choice)
                {
                    case '1':
                        AddStudent();
                        break;
                    case '2':
                        EditStudent();
                        break;
                    case '3':
                        PrintStudentsQueue();
                        break;
                    case '4':
                        SaveToFile();
                        break;
                    case '5':
                        repeat = false;
                        break;
                    default:
                        Console.WriteLine("Некорректный ввод. Попробуйте еще раз.");
                        break;
                }

                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey(true);

            } while (repeat);
        }

        static void AddStudent()
        {
            if (students.Count >= 25)
            {
                Console.WriteLine("Достигнуто максимальное количество студентов (25). Невозможно добавить больше.");
                return;
            }

            Student newStudent;

            Console.WriteLine("Введите ФИО студента:");
            newStudent.FullName = Console.ReadLine();

            Console.WriteLine("Введите город:");
            newStudent.City = Console.ReadLine();

            Console.WriteLine("Введите улицу:");
            newStudent.Street = Console.ReadLine();

            Console.WriteLine("Введите дом-квартиру:");
            newStudent.HouseApartment = Console.ReadLine();

            Console.WriteLine("Введите приблизительное расстояние до Краснодара (в километрах):");
            int distance;
            while (!int.TryParse(Console.ReadLine(), out distance) || distance < 0)
            {
                Console.WriteLine("Некорректный ввод. Введите целое положительное число:");
            }
            newStudent.DistanceToKrasnodar = distance;

            students.Add(newStudent);
            Console.WriteLine("Студент успешно добавлен.");
        }

        static void EditStudent()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("Список студентов пуст. Нет данных для редактирования.");
                return;
            }

            Console.WriteLine("Выберите номер студента для редактирования:");
            PrintStudentsList();

            int index;
            while (!int.TryParse(Console.ReadLine(), out index) || index < 1 || index > students.Count)
            {
                Console.WriteLine("Некорректный ввод. Введите номер студента из списка:");
            }

            index--; // перевод номера в индекс списка

            Student editedStudent = students[index];

            Console.WriteLine($"Текущие данные студента:\n{editedStudent}");

            Console.WriteLine("Введите новые данные:");

            Console.WriteLine("ФИО студента:");
            editedStudent.FullName = Console.ReadLine();

            Console.WriteLine("Город:");
            editedStudent.City = Console.ReadLine();

            Console.WriteLine("Улица:");
            editedStudent.Street = Console.ReadLine();

            Console.WriteLine("Дом-квартира:");
            editedStudent.HouseApartment = Console.ReadLine();

            Console.WriteLine("Приблизительное расстояние до Краснодара (в километрах):");
            int distance;
            while (!int.TryParse(Console.ReadLine(), out distance) || distance < 0)
            {
                Console.WriteLine("Некорректный ввод. Введите целое положительное число:");
            }
            editedStudent.DistanceToKrasnodar = distance;

            students[index] = editedStudent;
            Console.WriteLine("Данные студента успешно отредактированы.");
        }

        static void PrintStudentsQueue()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("Список студентов пуст.");
                return;
            }

            // Сортировка студентов по расстоянию до Краснодара (по возрастанию)
            List<Student> sortedStudents = students.OrderBy(s => s.DistanceToKrasnodar).ToList();

            Console.WriteLine("Очередь студентов для общежития (по расстоянию до Краснодара):");
            for (int i = 0; i < sortedStudents.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {sortedStudents[i]}");
            }
        }

        static void PrintStudentsList()
        {
            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {students[i].FullName}");
            }
        }

        static void SaveToFile()
        {
            if (students.Count == 0)
            {
                Console.WriteLine("Список студентов пуст. Нет данных для сохранения.");
                return;
            }

            string filePath = "students.txt";

            try
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (Student student in students)
                    {
                        writer.WriteLine($"{student.FullName};{student.City};{student.Street};{student.HouseApartment};{student.DistanceToKrasnodar}");
                    }
                }

                Console.WriteLine($"Данные успешно сохранены в файл: {filePath}");
            }
            catch (IOException e)
            {
                Console.WriteLine($"Ошибка при записи в файл: {e.Message}");
            }
        }
    }

}
