﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    using System;
    using System.Collections.Generic;

    // Класс для представления теста
    class Test
    {
        // Вложенный класс для представления вопроса
        public class Question
        {
            public string QuestionText { get; set; }
            public List<string> Options { get; set; }
            public int CorrectOptionIndex { get; set; }
            public int Points { get; set; }

            public void DisplayQuestion()
            {
                Console.WriteLine(QuestionText);
                for (int i = 0; i < Options.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {Options[i]}");
                }
            }
        }

        // Вложенный класс для представления ответов пользователя
        public class Answers
        {
            public List<int> SelectedOptions { get; set; }

            public Answers()
            {
                SelectedOptions = new List<int>();
            }

            public void AddAnswer(int optionIndex)
            {
                SelectedOptions.Add(optionIndex);
            }
        }

        private List<Question> questions;

        public Test()
        {
            questions = new List<Question>();
        }

        public void AddQuestion(Question question)
        {
            questions.Add(question);
        }

        public void RunTest()
        {
            int totalPoints = 0;
            int correctAnswers = 0;
            int incorrectAnswers = 0;

            foreach (Question question in questions)
            {
                Console.WriteLine("-------------------------------------------------");
                question.DisplayQuestion();
                Console.Write("Введите номер выбранного варианта ответа: ");
                int selectedOption = Convert.ToInt32(Console.ReadLine()) - 1;

                if (selectedOption >= 0 && selectedOption < question.Options.Count)
                {
                    if (selectedOption == question.CorrectOptionIndex)
                    {
                        Console.WriteLine("Ответ верный!");
                        totalPoints += question.Points;
                        correctAnswers++;
                    }
                    else
                    {
                        Console.WriteLine("Ответ неверный.");
                        incorrectAnswers++;
                    }
                }
                else
                {
                    Console.WriteLine("Некорректный номер варианта ответа.");
                }
            }

            Console.WriteLine("\nРезультаты теста:");
            Console.WriteLine($"Количество правильных ответов: {correctAnswers}");
            Console.WriteLine($"Количество неправильных ответов: {incorrectAnswers}");
            Console.WriteLine($"Набрано баллов: {totalPoints}");
        }
    }

    class Program
    {
        static void Main()
        {
            // Создаем объект теста
            Test test = new Test();

            // Добавляем вопросы
            Test.Question question1 = new Test.Question
            {
                QuestionText = "Какой язык программирования вы изучаете?",
                Options = new List<string> { "Java", "Python", "C#", "JavaScript" },
                CorrectOptionIndex = 2,
                Points = 10
            };

            Test.Question question2 = new Test.Question
            {
                QuestionText = "Что такое IDE?",
                Options = new List<string> { "Интерпретатор", "Интегрированная среда разработки", "Инструмент для анализа кода", "Игровой движок" },
                CorrectOptionIndex = 1,
                Points = 8
            };
            Test.Question question3 = new Test.Question
            {
                QuestionText = "Кто лучший преподаватель?",
                Options = new List<string> { "Белоус", "Парван", "Балашева", "Шандригоз" },
                CorrectOptionIndex = 0,
                Points = 10
            };

            // Добавляем вопросы в тест
            test.AddQuestion(question1);
            test.AddQuestion(question2);
            test.AddQuestion(question3);

            // Запускаем тест
            test.RunTest();
            Console.ReadKey();
        }
    }
}