﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

// Класс для представления экзамена
class Exam
{
    public string Subject { get; set; }
    public string TeacherName { get; set; }
    public string Group { get; set; }
    public string RoomNumber { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
}

class Program
{
    static void Main()
    {
        // Пример данных (можно заменить на ввод с консоли или другой источник данных)
        List<Exam> exams = new List<Exam>
        {
            new Exam {
                Subject = "Информатика",
                TeacherName = "Смирнов В.И.",
                Group = "Группа 1",
                RoomNumber = "101",
                StartTime = new DateTime(2024, 6, 10, 9, 0, 0),
                EndTime = new DateTime(2024, 6, 10, 11, 0, 0)
            },
            new Exam {
                Subject = "Физика",
                TeacherName = "Иванов А.П.",
                Group = "Группа 2",
                RoomNumber = "102",
                StartTime = new DateTime(2024, 6, 10, 11, 30, 0),
                EndTime = new DateTime(2024, 6, 10, 13, 30, 0)
            },
            new Exam {
                Subject = "Информатика",
                TeacherName = "Петров Б.С.",
                Group = "Группа 3",
                RoomNumber = "103",
                StartTime = new DateTime(2024, 6, 11, 10, 0, 0),
                EndTime = new DateTime(2024, 6, 11, 12, 0, 0)
            },
            new Exam {
                Subject = "Математика",
                TeacherName = "Сидоров Г.М.",
                Group = "Группа 1",
                RoomNumber = "104",
                StartTime = new DateTime(2024, 6, 11, 12, 30, 0),
                EndTime = new DateTime(2024, 6, 11, 15, 0, 0)
            }
        };

        // Запись данных в файлы по дням недели
        WriteExamsToFileByWeekday(exams);

        // Пример выполнения задач:
        DateTime dateToQuery = new DateTime(2024, 6, 10);

        // Подсчет количества экзаменов по информатике и их общая длительность
        int countComputingExams = CountComputingExams(exams, dateToQuery);
        TimeSpan totalComputingDuration = TotalComputingDuration(exams, dateToQuery);

        Console.WriteLine($"Количество экзаменов по информатике: {countComputingExams}");
        Console.WriteLine($"Общая длительность экзаменов по информатике: {totalComputingDuration.TotalHours} часов");

        // Поиск самого позднего времени окончания экзамена для заданной даты
        DateTime latestEndTime = LatestEndTimeForDate(exams, dateToQuery);
        Console.WriteLine($"Самое позднее время окончания экзамена на {dateToQuery.ToString("ddMMyyyy")}: {latestEndTime.ToString("HH:mm:ss")}");
        Console.ReadKey();
    }

    // Запись данных экзаменов в файлы по дням недели
    static void WriteExamsToFileByWeekday(List<Exam> exams)
    {
        foreach (var exam in exams)
        {
            string weekdayFileName = exam.StartTime.DayOfWeek.ToString(); // Получаем день недели в виде строки (например, "Monday")
            string fileName = $"{weekdayFileName}.txt";

            using (StreamWriter writer = File.AppendText(fileName))
            {
                writer.WriteLine($"Предмет: {exam.Subject}");
                writer.WriteLine($"ФИО преподавателя: {exam.TeacherName}");
                writer.WriteLine($"Группа: {exam.Group}");
                writer.WriteLine($"№ аудитории: {exam.RoomNumber}");
                writer.WriteLine($"Дата начала: {exam.StartTime.ToString("ddMMyyyy HH:mm:ss")}");
                writer.WriteLine($"Дата окончания: {exam.EndTime.ToString("ddMMyyyy HH:mm:ss")}");
                writer.WriteLine();
            }
        }
    }

    // Подсчет количества экзаменов по информатике на заданную дату
    static int CountComputingExams(List<Exam> exams, DateTime date)
    {
        return exams.Count(exam => exam.Subject == "Информатика" && exam.StartTime.Date == date.Date);
    }

    
    // Вычисление общей длительности экзаменов по информатике на заданную дату
    static TimeSpan TotalComputingDuration(List<Exam> exams, DateTime date)
    {
        return TimeSpan.FromMinutes(exams.Where(exam => exam.Subject == "Информатика" && exam.StartTime.Date == date.Date)
                                        .Sum(exam => (exam.EndTime - exam.StartTime).TotalMinutes));
    }

    // Поиск самого позднего времени окончания экзамена на заданную дату
    static DateTime LatestEndTimeForDate(List<Exam> exams, DateTime date)
    {
        return exams.Where(exam => exam.StartTime.Date == date.Date)
                    .Select(exam => exam.EndTime)
                    .Max();
    }
}
