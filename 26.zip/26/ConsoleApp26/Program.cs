﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp26
{
    class Program
    {
        static void Main()
        {
            // Ввод данных
            Console.WriteLine("Введите время начала звонка (ДДММГГГГ ЧЧ:ММ:СС):");
            string startTimeInput = Console.ReadLine();

            Console.WriteLine("Введите время окончания звонка (ДДММГГГГ ЧЧ:ММ:СС):");
            string endTimeInput = Console.ReadLine();

            Console.WriteLine("Введите стоимость одной минуты разговора (в копейках):");
            int costPerMinute = Convert.ToInt32(Console.ReadLine());

            // Преобразование строк в DateTime
            DateTime startTime = ParseDateTime(startTimeInput);
            DateTime endTime = ParseDateTime(endTimeInput);

            // Рассчитываем длительность звонка в секундах
            TimeSpan callDuration = endTime - startTime;
            int durationInSeconds = (int)callDuration.TotalSeconds;

            // Рассчитываем стоимость разговора в гривнах
            decimal costInHryvnias = CalculateCost(durationInSeconds, costPerMinute);

            // Вывод результатов
            Console.WriteLine($"Длительность звонка: {durationInSeconds} секунд");
            Console.WriteLine($"Стоимость разговора: {costInHryvnias} гривен");
            Console.ReadKey();
        }

        // Метод для преобразования строки в DateTime
        static DateTime ParseDateTime(string input)
        {
            string dateFormat = "ddMMyyyy HH:mm:ss";
            return DateTime.ParseExact(input, dateFormat, null);
        }

        // Метод для расчета стоимости разговора в гривнах
        static decimal CalculateCost(int durationInSeconds, int costPerMinute)
        {
            decimal costPerSecond = (decimal)costPerMinute / 60 / 100; // стоимость одной секунды разговора в гривнах
            decimal totalCost = durationInSeconds * costPerSecond;
            return totalCost;
        }
    }
}
