﻿using System;
using System.Collections.Generic;
using System.Globalization;

// Класс для представления экзамена
class Exam
{
    public string Subject { get; set; }
    public string TeacherName { get; set; }
    public string Group { get; set; }
    public string RoomNumber { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
}

class Program
{
    static void Main()
    {
        // Создаем список экзаменов
        List<Exam> exams = new List<Exam>();

        // Ввод данных о экзаменах
        Console.WriteLine("Введите информацию о расписании экзаменов (для завершения введите 'end'):");
        string input;
        do
        {
            Console.WriteLine("Предмет:");
            string subject = Console.ReadLine();
            if (subject.ToLower() == "end")
                break;

            Console.WriteLine("ФИО преподавателя:");
            string teacherName = Console.ReadLine();

            Console.WriteLine("Группа:");
            string group = Console.ReadLine();

            Console.WriteLine("№ аудитории:");
            string roomNumber = Console.ReadLine();

            Console.WriteLine("Дата начала (ДДММГГГГ ЧЧ:ММ:СС):");
            DateTime startTime = ParseDateTime(Console.ReadLine());

            Console.WriteLine("Дата окончания (ДДММГГГГ ЧЧ:ММ:СС):");
            DateTime endTime = ParseDateTime(Console.ReadLine());

            // Создаем объект экзамена и добавляем в список
            exams.Add(new Exam
            {
                Subject = subject,
                TeacherName = teacherName,
                Group = group,
                RoomNumber = roomNumber,
                StartTime = startTime,
                EndTime = endTime
            });

            Console.WriteLine("Введите следующий экзамен или 'end', чтобы завершить:");
            input = Console.ReadLine();
        } while (input.ToLower() != "end");

        // Вывод расписания экзаменов
        Console.WriteLine("\nРасписание экзаменов:");
        foreach (var exam in exams)
        {
            // Проверяем, что экзамен начинается до 12:00
            if (exam.StartTime.Hour < 12)
            {
                Console.WriteLine($"Предмет: {exam.Subject}");
                Console.WriteLine($"ФИО преподавателя: {exam.TeacherName}");
                Console.WriteLine($"Группа: {exam.Group}");
                Console.WriteLine($"№ аудитории: {exam.RoomNumber}");
                Console.WriteLine($"Дата начала: {exam.StartTime.ToString("ddMMyyyy HH:mm:ss")}");
                Console.WriteLine($"Дата окончания: {exam.EndTime.ToString("ddMMyyyy HH:mm:ss")}");
                Console.WriteLine();
            }
        }

        Console.WriteLine("Программа завершила работу.");
        Console.ReadKey();
    }

    // Метод для преобразования строки в DateTime
    static DateTime ParseDateTime(string input)
    {
        string dateFormat = "ddMMyyyy HH:mm:ss";
        return DateTime.ParseExact(input, dateFormat, CultureInfo.InvariantCulture);
    }
}
