﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp21
{
  

    class Program
    {
        static void Main()
        {
            try
            {
                // Создаем объекты даты с различными значениями
                Date date1 = new Date(25, 6, 2024);
                Date date2 = new Date(31, 12, 2024);

                // Выводим даты в текстовом формате
                Console.WriteLine("Дата 1: " + date1);
                Console.WriteLine("Дата 2: " + date2);

                // Проверяем, является ли год високосным
                Console.WriteLine("Год 2024 високосный? " + (date1.IsLeapYear() ? "Да" : "Нет"));

                // Получаем следующий и предыдущий день
                Date nextDay = date1.Next();
                Date prevDay = date1.Prev();

                Console.WriteLine("Следующий день после " + date1 + ": " + nextDay);
                Console.WriteLine("Предыдущий день до " + date1 + ": " + prevDay);

                // Прибавляем и вычитаем дни
                int daysToAdd = 5;
                int daysToSubtract = 3;

                Date date3 = date1 + daysToAdd;
                Date date4 = date1 - daysToSubtract;

                Console.WriteLine($"Через {daysToAdd} дней после {date1}: {date3}");
                Console.WriteLine($"Через {daysToSubtract} дней до {date1}: {date4}");
            }
            catch (ArgumentException e)
            {
                Console.WriteLine("Ошибка при создании даты: " + e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Произошла ошибка: " + e.Message);
            }
            Console.ReadKey();
        }
    }

public class Date
    {
        private int day;
        private int month;
        private int year;

        // Дополнительные поля
        private string dayOfWeek;  // День недели
        private string holidayName; // Название праздника
        private bool isWeekend;  // Является ли выходным днем

        // Конструктор
        public Date(int day, int month, int year)
        {
            if (year > 0)
            {
                this.year = year;
            }
            else
            {
                throw new ArgumentException("Год должен быть положительным числом.");
            }

            if (month >= 1 && month <= 12)
            {
                this.month = month;
            }
            else
            {
                throw new ArgumentException("Месяц должен быть числом от 1 до 12.");
            }

            if (day >= 1 && day <= DateTime.DaysInMonth(year, month))
            {
                this.day = day;
            }
            else
            {
                throw new ArgumentException("Неверное значение дня для указанного месяца и года.");
            }

            // Инициализация дополнительных полей
            this.dayOfWeek = GetDayOfWeek();
            this.holidayName = "";
            this.isWeekend = IsWeekend();
        }

        // Копирующий конструктор
        public Date(Date other)
        {
            this.day = other.day;
            this.month = other.month;
            this.year = other.year;
            this.dayOfWeek = other.dayOfWeek;
            this.holidayName = other.holidayName;
            this.isWeekend = other.isWeekend;
        }

        // Методы Next и Prev для получения следующего и предыдущего дней
        public Date Next()
        {
            int nextDay = this.day + 1;
            int daysInMonth = DateTime.DaysInMonth(this.year, this.month);

            if (nextDay > daysInMonth)
            {
                nextDay = 1;
                int nextMonth = this.month + 1;
                if (nextMonth > 12)
                {
                    nextMonth = 1;
                    this.year++;
                }
                return new Date(nextDay, nextMonth, this.year);
            }

            return new Date(nextDay, this.month, this.year);
        }

        public Date Prev()
        {
            int prevDay = this.day - 1;
            if (prevDay < 1)
            {
                int prevMonth = this.month - 1;
                if (prevMonth < 1)
                {
                    prevMonth = 12;
                    this.year--;
                }
                int daysInPrevMonth = DateTime.DaysInMonth(this.year, prevMonth);
                prevDay = daysInPrevMonth;
            }
            return new Date(prevDay, this.month, this.year);
        }

        // Метод для проверки високосного года
        public bool IsLeapYear()
        {
            return DateTime.IsLeapYear(this.year);
        }

        // Перегрузка операторов + и -
        public static Date operator +(Date date, int days)
        {
            DateTime dt = new DateTime(date.year, date.month, date.day).AddDays(days);
            return new Date(dt.Day, dt.Month, dt.Year);
        }

        public static Date operator -(Date date, int days)
        {
            DateTime dt = new DateTime(date.year, date.month, date.day).AddDays(-days);
            return new Date(dt.Day, dt.Month, dt.Year);
        }

        // Метод для вывода текстового представления даты
        public override string ToString()
        {
            string[] months = {"января", "февраля", "марта", "апреля", "мая", "июня",
                           "июля", "августа", "сентября", "октября", "ноября", "декабря"};
            return $"{this.day} {months[this.month - 1]} {this.year} г.";
        }

        // Приватные методы для вычисления дня недели и проверки на выходной
        private string GetDayOfWeek()
        {
            DateTime dt = new DateTime(this.year, this.month, this.day);
            return dt.ToString("dddd");
        }

        private bool IsWeekend()
        {
            DateTime dt = new DateTime(this.year, this.month, this.day);
            return dt.DayOfWeek == DayOfWeek.Saturday || dt.DayOfWeek == DayOfWeek.Sunday;
        }
    }

}
